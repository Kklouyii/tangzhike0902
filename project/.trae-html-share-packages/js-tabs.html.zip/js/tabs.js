/* 通用选项卡（tab）组件，可复用在任意页面
 *
 * 使用方法：
 *   1. 容器加 data-js-tabs；
 *   2. 选项卡按钮加 data-js-tabs-tab，放在带 data-js-tabs-tablist 的标签栏里；
 *   3. 内容面板加 data-js-tabs-panel，顺序与按钮一一对应；
 *   4. 引入本文件即可自动初始化，同一页面可以放多组选项卡，互不影响。
 *
 * 切换逻辑：先清除所有选项卡的选中状态，再设置当前元素的选中状态。
 */
(function (window, document) {
    'use strict';

    var jsTabsTabActive = 'js-tabs__tab--active';
    var jsTabsPanelActive = 'js-tabs__panel--active';

    /* 切换到第 index 个选项卡 */
    function jsTabsSwitch(root, jsTabsIndex) {
        var jsTabsTabs = root.querySelectorAll('[data-js-tabs-tab]');
        var jsTabsPanels = root.querySelectorAll('[data-js-tabs-panel]');
        var jsTabsCurrent = jsTabsTabs[jsTabsIndex];
        if (!jsTabsCurrent) return;

        // 第一步：清除所有选项卡的选中状态
        for (var jsTabsI = 0; jsTabsI < jsTabsTabs.length; jsTabsI++) {
            jsTabsTabs[jsTabsI].classList.remove(jsTabsTabActive);
            jsTabsTabs[jsTabsI].setAttribute('aria-selected', 'false');
            jsTabsTabs[jsTabsI].setAttribute('tabindex', '-1');
        }

        // 同时清除所有内容面板的显示状态
        for (var jsTabsJ = 0; jsTabsJ < jsTabsPanels.length; jsTabsJ++) {
            jsTabsPanels[jsTabsJ].classList.remove(jsTabsPanelActive);
        }

        // 第二步：设置当前元素的选中状态
        jsTabsCurrent.classList.add(jsTabsTabActive);
        jsTabsCurrent.setAttribute('aria-selected', 'true');
        jsTabsCurrent.setAttribute('tabindex', '0');
        if (jsTabsPanels[jsTabsIndex]) {
            jsTabsPanels[jsTabsIndex].classList.add(jsTabsPanelActive);
        }
    }

    /* 为单个选项卡容器绑定事件（重复调用不会重复绑定） */
    function jsTabsBind(root) {
        if (root.dataset.jsTabsReady === 'true') return;

        var jsTabsTablist = root.querySelector('[data-js-tabs-tablist]');
        if (!jsTabsTablist) return;

        // 事件监听：点击事件委托到标签栏上，新增的选项卡按钮也能响应
        jsTabsTablist.addEventListener('click', function (jsTabsEvent) {
            var jsTabsTarget = jsTabsEvent.target.closest('[data-js-tabs-tab]');
            if (!jsTabsTarget || !root.contains(jsTabsTarget)) return;

            var jsTabsTabs = root.querySelectorAll('[data-js-tabs-tab]');
            jsTabsSwitch(root, Array.prototype.indexOf.call(jsTabsTabs, jsTabsTarget));
        });

        // 键盘操作：左右方向键切换选项卡，Home / End 跳到首尾
        jsTabsTablist.addEventListener('keydown', function (jsTabsEvent) {
            var jsTabsKey = jsTabsEvent.key;
            if (jsTabsKey !== 'ArrowLeft' && jsTabsKey !== 'ArrowRight' &&
                jsTabsKey !== 'Home' && jsTabsKey !== 'End') {
                return;
            }

            var jsTabsTabs = root.querySelectorAll('[data-js-tabs-tab]');
            var jsTabsActive = root.querySelector('[data-js-tabs-tab][aria-selected="true"]');
            var jsTabsNow = Array.prototype.indexOf.call(jsTabsTabs, jsTabsActive);
            var jsTabsNext = jsTabsNow;

            if (jsTabsKey === 'ArrowLeft') jsTabsNext = (jsTabsNow + jsTabsTabs.length - 1) % jsTabsTabs.length;
            if (jsTabsKey === 'ArrowRight') jsTabsNext = (jsTabsNow + 1) % jsTabsTabs.length;
            if (jsTabsKey === 'Home') jsTabsNext = 0;
            if (jsTabsKey === 'End') jsTabsNext = jsTabsTabs.length - 1;

            jsTabsEvent.preventDefault();
            jsTabsSwitch(root, jsTabsNext);
            jsTabsTabs[jsTabsNext].focus();
        });

        // 默认项：优先取 aria-selected="true" 的按钮，否则取第一个
        var jsTabsFirst = root.querySelector('[data-js-tabs-tab][aria-selected="true"]') ||
            root.querySelector('[data-js-tabs-tab]');
        if (jsTabsFirst) {
            var jsTabsAll = root.querySelectorAll('[data-js-tabs-tab]');
            jsTabsSwitch(root, Array.prototype.indexOf.call(jsTabsAll, jsTabsFirst));
        }

        root.dataset.jsTabsReady = 'true';
    }

    /* 初始化页面上所有选项卡 */
    function jsTabsInit(jsTabsScope) {
        var jsTabsRoots = (jsTabsScope || document).querySelectorAll('[data-js-tabs]');
        for (var jsTabsI = 0; jsTabsI < jsTabsRoots.length; jsTabsI++) {
            jsTabsBind(jsTabsRoots[jsTabsI]);
        }
    }

    // 对外暴露，方便动态插入内容后手动初始化
    window.jsTabs = {
        init: jsTabsInit,
        switch: function (root, index) {
            jsTabsSwitch(root, index);
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            jsTabsInit();
        });
    } else {
        jsTabsInit();
    }
})(window, document);
